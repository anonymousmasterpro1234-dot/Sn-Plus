alias menu='/usr/local/bin/admbuho'
alias admbuho='/usr/local/bin/admbuho'

# Banner oficial ADMBuho en inicio interactivo SSH
if [ -z "$ADMBUHO_BANNER_SHOWN" ]; then
    case "${-:-}" in
        *i*)
            export ADMBUHO_BANNER_SHOWN=1
            [ -x /usr/local/bin/admbuho ] && /usr/local/bin/admbuho banner 2>/dev/null
            ;;
    esac
fi
